<?php
/* Smarty version 3.1.48, created on 2024-08-27 20:49:08
  from 'C:\xampp\htdocs\smarty\smarty-3.1.48\mydemo\template\mytemplate.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_66ce1fa4ec06a3_86378808',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '900640c8c9ffa47c153bad872317d4afb35aa539' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\smarty-3.1.48\\mydemo\\template\\mytemplate.tpl',
      1 => 1724783727,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ce1fa4ec06a3_86378808 (Smarty_Internal_Template $_smarty_tpl) {
}
}
