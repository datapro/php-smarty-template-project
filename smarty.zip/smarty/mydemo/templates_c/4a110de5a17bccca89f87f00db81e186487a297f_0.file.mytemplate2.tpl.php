<?php
/* Smarty version 3.1.48, created on 2024-08-27 21:36:40
  from 'C:\xampp\htdocs\smarty\smarty-3.1.48\mydemo\templates\mytemplate2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_66ce2ac8878083_42345551',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4a110de5a17bccca89f87f00db81e186487a297f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\smarty-3.1.48\\mydemo\\templates\\mytemplate2.tpl',
      1 => 1724787104,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ce2ac8878083_42345551 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<title>Info</title>
</head>
<body>
<table style="background:yellow">
    <tr>
        <td> Name: <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
 </td>

        <td> Address:<?php echo $_smarty_tpl->tpl_vars['address']->value;?>
</td>
</tr>
</table>
</body>
</html><?php }
}
