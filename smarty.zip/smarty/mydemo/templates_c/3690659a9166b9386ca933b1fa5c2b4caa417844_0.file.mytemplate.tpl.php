<?php
/* Smarty version 3.1.48, created on 2024-08-27 20:55:53
  from 'C:\xampp\htdocs\smarty\smarty-3.1.48\mydemo\mytemplate.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_66ce21398d5d88_12138493',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3690659a9166b9386ca933b1fa5c2b4caa417844' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\smarty-3.1.48\\mydemo\\mytemplate.tpl',
      1 => 1724784949,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ce21398d5d88_12138493 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<title>Info</title>
</head>
<body>

<pre>
User Information:

Name: <?php echo $_smarty_tpl->tpl_vars['name']->value;?>

Address: <?php echo $_smarty_tpl->tpl_vars['address']->value;?>

</pre>

</body>
</html><?php }
}
