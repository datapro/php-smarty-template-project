<?php /* Smarty version 3.1.48, created on 2024-08-27 20:31:12
         compiled from 'C:\xampp\htdocs\smarty\smarty-3.1.48\demo\configs\test.conf' */ ?>
<?php
/* Smarty version 3.1.48, created on 2024-08-27 20:31:12
  from 'C:\xampp\htdocs\smarty\smarty-3.1.48\demo\configs\test.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_66ce1b702ff5d2_07106873',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '53b840051e7c8ecf48dee1ec4f902d7dd12a902a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\smarty-3.1.48\\demo\\configs\\test.conf',
      1 => 1680032754,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ce1b702ff5d2_07106873 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
