<?php
/* Smarty version 3.1.48, created on 2024-08-27 20:31:12
  from 'C:\xampp\htdocs\smarty\smarty-3.1.48\demo\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_66ce1b7038d832_65237635',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f7f9bf0a1113071f509f4ce53082fa948808078' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\smarty-3.1.48\\demo\\templates\\footer.tpl',
      1 => 1680032754,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ce1b7038d832_65237635 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '23539907066ce1b7038a7e3_65397946';
?>
</BODY>
</HTML>
<?php }
}
