<?php
/* Smarty version 3.1.48, created on 2024-08-27 20:31:12
  from 'C:\xampp\htdocs\smarty\smarty-3.1.48\demo\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_66ce1b70342d01_19502475',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '40fc35f52effe6248eb1db1fb67a717ceea64461' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\smarty-3.1.48\\demo\\templates\\header.tpl',
      1 => 1680032754,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ce1b70342d01_19502475 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '140055353066ce1b7033db61_68486510';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:140055353066ce1b7033db61_68486510%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:140055353066ce1b7033db61_68486510%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
